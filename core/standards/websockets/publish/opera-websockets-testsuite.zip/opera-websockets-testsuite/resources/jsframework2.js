(function(){

// private

var testTimeoutId;

var pre = document.getElementsByTagName('pre')[0];
if (!pre) {
  pre = document.createElement('pre');
  pre.appendChild(document.createTextNode(''));
  window.addEventListener('DOMContentLoaded', function() {
    var pre_ = document.getElementsByTagName('pre')[0];
    if (pre_)
      pre_.parentNode.replaceChild(pre, pre_);
    else if (document.body)
      document.body.appendChild(pre);
  }, false);
}
pre.firstChild.data = 'Running...';
pre.appendChild(document.createTextNode('\n\n'));

var testIsRunning = function() {
  return pre.firstChild.data.substr(0, 10) == 'Running...';
}

var logContext = '';

var log = function(s) {
  if (testIsRunning())
    pre.firstChild.data = 'FAIL';
  pre.childNodes[1].data += logContext + s + '\n';
  end(s);
}

// public

window.setTestTimeout = function(t, msg) {
  clearTimeout(testTimeoutId);
  if (t == null) {
    if (testIsRunning())
      pre.firstChild.data = 'Running...';
  } else {
    testTimeoutId = setTimeout(function() {
      log('Test timed out'+(msg!==undefined?' ('+msg+')':''));
    }, t);
    if (testIsRunning())
      pre.firstChild.data = 'Running... (test times out after '+t+'ms)';
  }
}

setTestTimeout(3000);

window.end = function(s) {
  if (arguments.callee.done)
    return;
  arguments.callee.done = true;
  clearTimeout(testTimeoutId);
  if (testIsRunning()) {
    pre.firstChild.data = 'PASS';
    try{top.opener.rr(true)}catch(e){}
  } else {
    try{top.opener.rr(false, s)}catch(e){}
  }
}

window.assertEquals = function(a, b, msg) {
  if (a !== b)
    log('Got '+a+' ('+typeof a+'), expected '+b+' ('+typeof b+')'+(msg!==undefined?' ('+msg+')':''));
}

window.assertNotEquals = function(a, b, msg) {
  if (a === b)
    log('Got '+a+' ('+typeof a+'), expected something else'+(msg!==undefined?' ('+msg+')':''));
}

window.assertLessThan = function(a, b, msg) {
  if (!(a < b))
    log('Got '+a+' ('+typeof a+'), expected something less than '+b+' ('+typeof b+')'+(msg!==undefined?' ('+msg+')':''));
}

window.assertGreaterThan = function(a, b, msg) {
  if (!(a > b))
    log('Got '+a+' ('+typeof a+'), expected something greater than '+b+' ('+typeof b+')'+(msg!==undefined?' ('+msg+')':''));
}

window.assertApprox = function(a, b, tolerance, msg) {
  if (Math.abs(a-b) > tolerance)
    log('Got '+a+' ('+typeof a+'), expected '+b+' \u00B1'+tolerance+' ('+typeof b+')'+(msg!==undefined?' ('+msg+')':''));
}

window.assertNaN = function(a, msg) {
  if (a === a)
    log('Got '+a+' ('+typeof a+'), expected NaN (number)'+(msg!==undefined?' ('+msg+')':''));
}

window.assertMatches = function(a, regexp, msg) {
  if (!regexp.test(a))
    log('Got '+a+' ('+typeof a+'), expected something that matches '+regexp+(msg!==undefined?' ('+msg+')':''));
}

window.assertNotMatches = function(a, regexp, msg) {
  if (regexp.test(a))
    log('Got '+a+' ('+typeof a+'), expected something that doesn\'t match '+regexp+(msg!==undefined?' ('+msg+')':''));
}

window.assertInstanceOf = function(a, b, msg) {
  try {
    if (!(a instanceof b))
      log(a+' ('+typeof a+') was not an instance of '+b+' ('+typeof b+')'+(msg!==undefined?' ('+msg+')':''));
  } catch(e) {
    log(a+' ('+typeof a+') instanceof '+b+' ('+typeof b+')'+(msg!==undefined?' ('+msg+')':'')+' raised an unexpected exception: '+e.message);
  }
}

window.assertThrows = function(a, b, msg) {
  try {
    a();
    log(a+(msg!==undefined?' ('+msg+')':'')+' didn\'t throw, expected an exception');
  } catch(e) {
    logContext = a+(msg!==undefined?' ('+msg+'): ':': ');
    try {
      b(e);
    } catch(ee) {
      log('assertThrows callback '+b+' raised an unexpected exception: '+ee.message);
    }
    logContext = '';
  }
}

window.assertNotThrows = function(a, msg) {
  try {
    a();
  } catch(e) {
    log(a+(msg!==undefined?' ('+msg+')':'')+' raised an unexpected exception: '+e.message);
  }
}

window.assertUnreached = function(msg) {
  if (msg instanceof Event)
    msg = msg.type;
  log('Reached code that should not be executed'+(msg!==undefined?' ('+msg+')':''));
}

window.debug = function(msg) {
  if (msg instanceof Event)
    msg = msg.type;
  pre.childNodes[1].data += '(Debug info: ' + msg + ')\n';
}

})();