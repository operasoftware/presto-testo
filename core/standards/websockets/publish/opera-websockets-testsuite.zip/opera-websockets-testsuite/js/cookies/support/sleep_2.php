<?php
sleep(2);
?>