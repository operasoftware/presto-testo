This testsuite tests the WebSocket protocol version -00 (aka -76) and the WebSocket API editor's draft as it stood circa July 2010.

http://tools.ietf.org/html/draft-ietf-hybi-thewebsocketprotocol-00 
http://dev.w3.org/html5/websockets/

This testsuite requires pywebsocket. The tests expect the server to respond on port 8007 using the handlers in websock_handlers.

http://code.google.com/p/pywebsocket/

If you intend to use standalone.py, please note the following:

[[
SECURITY WARNING: This uses CGIHTTPServer and CGIHTTPServer is not secure.
It may execute arbitrary Python code or external programs. It should not be
used outside a firewall.
]] -- http://code.google.com/p/pywebsocket/source/browse/trunk/src/mod_pywebsocket/standalone.py

The tests expect the root-relative URL /resources/jsframework2.js to point to the jsframework2.js file.

The constants.js file needs to be edited if the websocket server uses a different domain than the tests.

To run the tests with TSL, append ?wss to the URL for the test.

Use js/runner.php to run automated tests. The test framework uses try{top.opener.rr(result)}catch(e){} to communicate the test result to the runner.

If anything is unclear, email Simon Pieters <simonp@opera.com>.